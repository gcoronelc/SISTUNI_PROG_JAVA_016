
package pe.egcc.genioapp.control;

import pe.egcc.genioapp.service.GenioService;


public class GenioController {

    public long factorial(int n) {
       return GenioService.factorial(n);
    }

    public int mcm(int n1, int n2){
        return GenioService.mcm(n1, n2);
    }
    
    public int mcd(int n1, int n2){
        return GenioService.mcd(n1, n2);
    }
    
    public boolean primo(int n1){
        return GenioService.esPrimo(n1);
    }
    public String fibonacci(int n1){
        return GenioService.fibonacci(n1);
    
    }
}
