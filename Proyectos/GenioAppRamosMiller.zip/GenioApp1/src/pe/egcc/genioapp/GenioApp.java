
package pe.egcc.genioapp;

import pe.egcc.genioapp.view.MainView;

/**
 *
 * @author alumno
 */
public class GenioApp {

public static void main(String[] args) {
      
    MainView.main(args);
}
    
}
