/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.egcc.promedioapp;

import pe.egcc.promedioapp.view.PromedioView;

/**
 *
 * @author alumno
 */
public class ClasePrincipal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PromedioView prom = new PromedioView();
        prom.setVisible(true);
    }
    
}
