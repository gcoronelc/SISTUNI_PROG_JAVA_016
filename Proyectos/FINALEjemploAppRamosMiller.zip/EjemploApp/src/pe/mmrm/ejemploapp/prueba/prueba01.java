/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.mmrm.ejemploapp.prueba;

import pe.mmrm.ejemploapp.model.Trabajador;
import pe.mmrm.ejemploapp.service.Secretaria;
import pe.mmrm.ejemploapp.service.TrabajadorAbs;


public class prueba01 {
    public static void main(String[] args) {
    // Dato
    double total = 1000;
    String cargo = "Secretaria";   
// Proceso
        TrabajadorAbs comp = new Secretaria() ;
    Trabajador[] repo = comp.procesar(cargo, total);
    // Reporte
    for(Trabajador bean: repo){
      System.out.println(bean.getCargo()+ "\t" + bean.getSueldo());
    }
  }
}
