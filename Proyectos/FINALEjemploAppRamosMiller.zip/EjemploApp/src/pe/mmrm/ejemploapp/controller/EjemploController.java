
package pe.mmrm.ejemploapp.controller;

import pe.mmrm.ejemploapp.model.Trabajador;
import pe.mmrm.ejemploapp.service.ReporteFactory;

/**
 *
 * @author PC-CASA
 */
public class EjemploController {
    public String[] getTipos(){
           return ReporteFactory.getTipos();
    }
    
     public Trabajador[] procesar(String tipo, double salario){
    return ReporteFactory.crear(tipo).procesar(tipo,salario);
  }
}
