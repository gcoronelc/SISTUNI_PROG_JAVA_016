package pe.mmrm.ejemploapp.service;

/**
 *
 * @author PC-CASA
 */
public final class ReporteFactory {

    private ReporteFactory() {

    }
    
    public static final String ASISTENTE = "Asistente";
        public static final String COORDINADOR = "Coordinador";
    public static final String DOCENTE = "Docente";
    public static final String SECRETARIA = "Secretaria";

    public static final String[] getTipos() {
        String[] tipos = {ASISTENTE, COORDINADOR, DOCENTE, SECRETARIA};
        return tipos;
    }

    public static final TrabajadorAbs crear(String tipo) {
        TrabajadorAbs bean = null;
        // Proceso
        switch (tipo) {
            case DOCENTE:
                bean = new Docente();
                break;
            case COORDINADOR:
                bean = new Coordinador();
                break;
            case ASISTENTE:
                bean = new Asistente();
                break;
            case SECRETARIA:
                bean = new Secretaria();
                break;
        }

        return bean;
    }
}
