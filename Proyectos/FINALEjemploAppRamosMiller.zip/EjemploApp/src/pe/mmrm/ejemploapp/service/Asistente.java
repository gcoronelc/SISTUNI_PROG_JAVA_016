
package pe.mmrm.ejemploapp.service;

import pe.mmrm.ejemploapp.model.Trabajador;

/**
 *
 * @author PC-CASA
 */
public class Asistente extends Empleado{

    @Override
    public Trabajador[] procesar(String cargo, double salario) {
        salario = 4000;
        double bono = salario*0.7;
        
        Trabajador [] repo = {
        new Trabajador ("Sueldo",salario),
        new Trabajador ("Bono",bono),
        new Trabajador ("Total ",salario+bono)
    };
        
        return repo;
    }



}
