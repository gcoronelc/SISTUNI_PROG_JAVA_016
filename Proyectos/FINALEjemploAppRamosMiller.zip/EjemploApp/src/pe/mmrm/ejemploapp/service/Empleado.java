
package pe.mmrm.ejemploapp.service;


/**
 *
 * @author PC-CASA
 */
public abstract class Empleado extends TrabajadorAbs{
   
}
