
package pe.mmrm.ejemploapp.service;

import pe.mmrm.ejemploapp.model.Trabajador;

/**
 *
 * @author PC-CASA
 */

public abstract class TrabajadorAbs {
    
    public abstract Trabajador[] procesar (String cargo, double salario);

}
