/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.mmrm.ejemploapp.service;

import pe.mmrm.ejemploapp.model.Trabajador;

/**
 *
 * @author PC-CASA
 */
public class Coordinador extends Empleado {

    @Override
    public Trabajador[] procesar(String cargo, double salario) {
        salario = 5000;
        double bono = salario*0.7;
        
        Trabajador [] repo = {
        new Trabajador ("Sueldo",salario),
        new Trabajador ("Bono",bono),
        new Trabajador ("Total ",salario+bono)
    };
        
        return repo;
    }

}
