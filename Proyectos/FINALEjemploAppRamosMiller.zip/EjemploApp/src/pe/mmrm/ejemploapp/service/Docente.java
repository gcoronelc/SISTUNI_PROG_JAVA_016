package pe.mmrm.ejemploapp.service;

import pe.mmrm.ejemploapp.model.Trabajador;
import pe.mmrm.ejemploapp.view.*;
/**
 *
 * @author PC-CASA
 */
public class Docente extends TrabajadorAbs {

    @Override
    public Trabajador[] procesar(String cargo, double salario) {
        double bono = salario*1;
        
        Trabajador [] repo = {
        new Trabajador ("Sueldo",salario),
        new Trabajador ("Bono",bono),
        new Trabajador ("Total ",salario+bono)
    };
        
        return repo;
    }

    
    

}
