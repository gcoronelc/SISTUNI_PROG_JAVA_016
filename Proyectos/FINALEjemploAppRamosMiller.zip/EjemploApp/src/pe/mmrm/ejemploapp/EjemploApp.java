
package pe.mmrm.ejemploapp;

import pe.mmrm.ejemploapp.view.ProyectoView;

/**
 *
 * @author PC-CASA
 */
public class EjemploApp {

   
    public static void main(String[] args) {
        ProyectoView.main(args);
    }
    
}
