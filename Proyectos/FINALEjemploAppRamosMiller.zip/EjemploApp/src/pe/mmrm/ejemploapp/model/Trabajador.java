
package pe.mmrm.ejemploapp.model;

/**
 *
 * @author PC-CASA
 */
public class Trabajador {
    private String cargo;
    private double sueldo;

    public Trabajador(String cargo, double sueldo) {
        this.cargo = cargo;
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return "Trabajador{" + ", cargo=" + cargo + ", sueldo=" + sueldo + '}';
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    
}
